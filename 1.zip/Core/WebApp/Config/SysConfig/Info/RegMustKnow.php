<?php /* 请务必不要改动这一行，否则会有安全隐患！ */ if(!defined('RootDir'))exit('Access Denied'); ?>
<p>
	<span style="font-size: 18px;" font-size:16px;"="">欢迎您使用绚丽彩虹同学录！</span> 
</p>
<p>
	<br />
</p>
<p>
	<span style="font-family:" font-size:16px;"=""><span style="font-size:18px;">在注册之前，</span><strong><span style="font-size:18px;">请您阅读以下注意事项：</span></strong></span> 
</p>
<p>
	<span style="font-family:" font-size:16px;"=""><span style="font-size:18px;">1.非本班人</span><strong><span style="font-size:18px;">请勿注册</span></strong><span style="font-size:18px;">。</span></span> 
</p>
<p>
	<span style="font-family:" font-size:16px;"=""><span style="font-size:18px;">2.您需要获得</span><strong><span style="font-size:18px;">班级密码</span></strong><span style="font-size:18px;">，才能够注册本站账户，请联系网站管理员获取。</span></span> 
</p>
<p>
	<span style="font-family:" font-size:16px;"=""><span style="font-size:18px;">3.请您尊重他人，请勿</span><strong><span style="font-size:18px;">发表过激言论、上传淫秽信息、辱骂他人</span></strong><span style="font-size:18px;">。</span></span> 
</p>
<p>
	<span style="font-family:" font-size:16px;"=""><span style="font-size:18px;">4.请您做好</span><strong><span style="font-size:18px;">保密工作</span></strong><span style="font-size:18px;">。请勿</span><strong><span style="font-size:18px;">将其他同学的资料发布给站外人员</span></strong><span style="font-size:18px;">。</span></span> 
</p>
<p>
	<span style="font-family:" font-size:16px;"=""><span style="font-size:18px;">5.不要</span><strong><span style="font-size:18px;">泄露</span></strong><span style="font-size:18px;">班级密码。</span></span> 
</p>
<p>
	<span style="font-family:" font-size:16px;"=""><br />
</span> 
</p>
<p>
	<span style="font-size:18px;"><span style="font-size:18px;">注册成功后，您将可以进入同学录系统。请您在个人主页完善您的资料以及密保信息。</span></span> 
</p>
<p>
	<span style="font-size:18px;"><span style="font-size:18px;">您可以在【同学录】查看其他同学的资料以及对他留言，在【相册】查看其他同学上传的照片以及分享你的照片，在【留言板】可以进行留言。</span></span> 
</p>
<p>
	<br />
</p>
<p>
	<span><span><span style="font-size:18px;">感谢您的使用，</span><a href="http://Flandre-Studio.cn" target="_blank"><span style="font-size:18px;">绚丽彩虹工作室</span></a><span style="font-size:18px;">全体成员敬上√</span></span></span> 
</p>