<?php
//设置应用目录
define("AppDir",RootDir."Core/WebApp/");
define("FunctionDir",RootDir."Function/");
define("TemplateDir",RootDir."Template/");
define("CoreDir",RootDir."XlchCore/");

//引入AdminPHP框架文件
include("AdminPHP/AdminPHP.php");