<?php
if(!defined("AdminPHP")) exit('<h1 style="color:red">Bad Reuest!</h1> <hr /> Powered By Xlch-AdminPHP');
?>
<!-- Your XlchPlayerKey -->
<script>XlchKey="<?=$WebConfig['Music']['BadApplePlayer']['Key']?>";</script>
<script>alert('很抱歉，播放器已停止运营，并且暂无恢复运营的打算。请您在网站配置关闭播放器，关注后续更新请添加QQ群161354496。');</script>
<!-- BadApplePlayer -->
<!-- <script src="http://static.badapple.top/BadApplePlayer/Player.js"></script> -->
<style>
.blur{
	z-index:-1;
}
.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
background: rgba(0,0,0,0);
}
.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar {
background: rgba(0,0,0,0);
}
.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar {
background: rgba(0,0,0,0);
}
</style>